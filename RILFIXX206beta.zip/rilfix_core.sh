#!/system/bin/sh

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] [rilfix-service] $1" >> /sdcard/rilfix.log
}

heartbeat_file="/sdcard/rilfix_heartbeat.txt"

start_main_loop() {
    (
        while true; do
            log "Restarting ril-daemon (main loop)..."
            stop ril-daemon
            sleep 3
            start ril-daemon
            echo "$(date '+%Y-%m-%d %H:%M:%S')" > "$heartbeat_file"
            log "RIL restarted. Sleeping 5 hours..."
            sleep 18000
        done
    ) &
    echo $! > /sdcard/rilfix_mainloop.pid
}

start_watchdog() {
    (
        while true; do
            sleep 30
            last_beat=$(stat -c %Y "$heartbeat_file" 2>/dev/null || echo 0)
            now=$(date +%s)
            age=$((now - last_beat))
            if [ "$age" -gt 18600 ]; then
                log "Watchdog: heartbeat too old ($age s). Respawning main loop..."
                pkill -f rilfix-service
                start_main_loop
            else
                log "Watchdog: heartbeat OK ($age s)"
            fi
        done
    ) &
    echo $! > /sdcard/rilfix_watchdog.pid
}
