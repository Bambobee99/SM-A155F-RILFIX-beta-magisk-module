#!/system/bin/sh

sleep 10

. /data/adb/modules/rilfix/rilfix_core.sh

now=$(date +%s)
last_beat=$(stat -c %Y "$heartbeat_file" 2>/dev/null || echo 0)
age=$((now - last_beat))

if [ "$age" -gt 21600 ]; then
    log "Reboot check: heartbeat old or missing. Restarting RIL now."
    stop ril-daemon
    sleep 3
    start ril-daemon
    echo "$(date '+%Y-%m-%d %H:%M:%S')" > "$heartbeat_file"
fi

log "Boot complete. Starting Final Defense..."
start_main_loop
start_watchdog
