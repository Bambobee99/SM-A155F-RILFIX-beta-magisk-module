#!/system/bin/sh
sh /data/adb/modules/rilfix/service.sh && sh /data/adb/modules/rilfix/rilfix_core.sh
